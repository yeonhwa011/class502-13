package org.choongang;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BoardYhApplication {

	public static void main(String[] args) {
		SpringApplication.run(BoardYhApplication.class, args);
	}

}
